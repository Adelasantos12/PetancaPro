import React from 'react';
import { motion } from 'framer-motion';
import { User, Users } from 'lucide-react';

const TeamCard = ({ team, onEdit, onDelete, showActions = true }) => {
  return (
    <motion.div
      className="bg-white rounded-xl shadow-md p-6 border border-gray-200 flex flex-col gap-4"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center gap-4">
        <div className="p-3 bg-blue-100 rounded-full">
          <Users className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-800">{team.name}</h3>
          <p className="text-gray-500 text-sm">Capitán: {team.captain}</p>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <p className="text-gray-600 font-medium">Jugadores:</p>
        <ul className="list-disc list-inside text-gray-500">
          {team.players.map((player, index) => (
            <li key={index} className="flex items-center gap-2">
              <User className="w-4 h-4 text-gray-400" /> {player}
            </li>
          ))}
        </ul>
      </div>
      {showActions && (
        <div className="flex gap-2 mt-4">
          <motion.button
            onClick={() => onEdit(team.id)}
            className="flex-1 px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg font-semibold hover:bg-yellow-200 transition-colors"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Editar
          </motion.button>
          <motion.button
            onClick={() => onDelete(team.id)}
            className="flex-1 px-4 py-2 bg-red-100 text-red-700 rounded-lg font-semibold hover:bg-red-200 transition-colors"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Eliminar
          </motion.button>
        </div>
      )}
    </motion.div>
  );
};

export default TeamCard;
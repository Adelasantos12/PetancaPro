import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shuffle, Play, ListOrdered, Award } from 'lucide-react';
import Button from '../components/Button';

const Tournament = ({ registeredTeams }) => {
  const [teams, setTeams] = useState([]);
  const [currentRound, setCurrentRound] = useState(0);
  const [matches, setMatches] = useState([]);
  const [showRanking, setShowRanking] = useState(false);

  useEffect(() => {
    if (registeredTeams.length > 0 && teams.length === 0) {
      setTeams(registeredTeams.map(team => ({
        ...team,
        wins: 0,
        losses: 0,
        points: 0,
        scoreDifference: 0,
        coefficient: 0,
        category: null, // A, B, C, AA, BB
        day2Status: null // 'advance', 'relegated'
      })));
    }
  }, [registeredTeams, teams.length]);

  const shuffleArray = (array) => {
    let currentIndex = array.length, randomIndex;
    while (currentIndex !== 0) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex], array[currentIndex]];
    }
    return array;
  };

  const generateFirstRoundMatches = () => {
    if (teams.length < 2) {
      alert('Necesitas al menos 2 equipos para generar partidos.');
      return;
    }
    const shuffledTeams = shuffleArray([...teams]);
    const newMatches = [];
    for (let i = 0; i < shuffledTeams.length; i += 2) {
      if (shuffledTeams[i + 1]) {
        newMatches.push({
          id: `match-${currentRound + 1}-${i / 2}`,
          team1: shuffledTeams[i],
          team2: shuffledTeams[i + 1],
          score1: '',
          score2: '',
          winnerId: null,
          played: false
        });
      } else {
        // Handle odd number of teams (bye) - for simplicity, we assume even for now
        // Or, implement a bye system
        console.warn("Número impar de equipos, un equipo tendrá bye en esta ronda.");
      }
    }
    setMatches(newMatches);
    setCurrentRound(1);
    setShowRanking(false);
  };

  const generateNextRoundMatches = () => {
    // This is where the Swiss system logic gets complex.
    // For now, a simplified version:
    // 1. Sort teams by wins, then coefficient.
    // 2. Pair teams with similar records. Avoid rematches.
    if (currentRound >= 5) {
      alert('¡Todas las rondas suizas han terminado!');
      return;
    }

    const sortedTeams = [...teams].sort((a, b) => {
      if (b.wins !== a.wins) return b.wins - a.wins;
      return b.coefficient - a.coefficient;
    });

    const newMatches = [];
    const availableTeams = new Set(sortedTeams.map(t => t.id));

    while (availableTeams.size >= 2) {
      let team1 = null;
      let team2 = null;

      // Simple pairing: take the first available team and try to find a match
      const team1Id = Array.from(availableTeams)[0];
      team1 = teams.find(t => t.id === team1Id);
      availableTeams.delete(team1Id);

      // Find a suitable opponent (not already played, similar record)
      for (const team2Id of Array.from(availableTeams)) {
        const potentialTeam2 = teams.find(t => t.id === team2Id);
        // Basic check: avoid rematches (needs more robust tracking)
        // For a real Swiss system, you'd track past opponents for each team
        const hasPlayed = false; // Placeholder for actual rematch check

        if (!hasPlayed) {
          team2 = potentialTeam2;
          availableTeams.delete(team2Id);
          break;
        }
      }

      if (team1 && team2) {
        newMatches.push({
          id: `match-${currentRound + 1}-${newMatches.length}`,
          team1: team1,
          team2: team2,
          score1: '',
          score2: '',
          winnerId: null,
          played: false
        });
      } else if (team1) {
        // Handle bye if odd number of teams
        console.warn(`${team1.name} tiene un BYE en esta ronda.`);
      }
    }

    setMatches(newMatches);
    setCurrentRound(prev => prev + 1);
    setShowRanking(false);
  };

  const handleScoreChange = (matchId, teamNum, value) => {
    setMatches(prev => prev.map(match =>
      match.id === matchId
        ? { ...match, [`score${teamNum}`]: value }
        : match
    ));
  };

  const recordMatchResult = (matchId) => {
    setMatches(prevMatches => prevMatches.map(match => {
      if (match.id === matchId && match.score1 !== '' && match.score2 !== '') {
        const score1 = parseInt(match.score1);
        const score2 = parseInt(match.score2);

        if (isNaN(score1) || isNaN(score2)) {
          alert('Por favor, introduce puntuaciones válidas.');
          return match;
        }

        let winnerId = null;
        let team1Points = 0;
        let team2Points = 0;

        if (score1 > score2) {
          winnerId = match.team1.id;
          team1Points = 1;
        } else if (score2 > score1) {
          winnerId = match.team2.id;
          team2Points = 1;
        } else {
          // Draw - petanca usually doesn't have draws, but if it does, adjust points
          alert('Empate no permitido en petanca. Debe haber un ganador.');
          return match;
        }

        const scoreDiff = score1 - score2;

        setTeams(prevTeams => prevTeams.map(team => {
          if (team.id === match.team1.id) {
            return {
              ...team,
              wins: team.wins + team1Points,
              losses: team.losses + team2Points,
              points: team.points + team1Points,
              scoreDifference: team.scoreDifference + scoreDiff,
              coefficient: team.points + team1Points + (team.scoreDifference + scoreDiff) / 100 // Simple coefficient
            };
          } else if (team.id === match.team2.id) {
            return {
              ...team,
              wins: team.wins + team2Points,
              losses: team.losses + team1Points,
              points: team.points + team2Points,
              scoreDifference: team.scoreDifference - scoreDiff,
              coefficient: team.points + team2Points + (team.scoreDifference - scoreDiff) / 100 // Simple coefficient
            };
          }
          return team;
        }));

        return { ...match, winnerId: winnerId, played: true };
      }
      return match;
    }));
  };

  const allMatchesPlayed = matches.every(match => match.played);

  const getRankedTeams = () => {
    return [...teams].sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      return b.coefficient - a.coefficient; // Tie-breaker
    });
  };

  const assignCategories = () => {
    const ranked = getRankedTeams();
    const updatedTeams = teams.map(team => {
      const rankIndex = ranked.findIndex(t => t.id === team.id);
      let category = null;
      if (rankIndex < 16) {
        category = 'A';
      } else if (rankIndex < 32) {
        category = 'B';
      } else {
        category = 'C';
      }
      return { ...team, category };
    });
    setTeams(updatedTeams);
  };

  const handleDay2AdvanceMatch = () => {
    // This is where the Day 2 logic for "advance or recategorization" would go.
    // It's quite complex as it involves specific pairings based on categories and results.
    // For now, a placeholder.
    alert('Lógica de partidos de avance/recategorización del Día 2 por implementar.');
    // After this, you'd generate the quarter-final groups.
  };

  const renderMatch = (match) => (
    <motion.div
      key={match.id}
      className="bg-white rounded-xl shadow-md p-4 border border-gray-200 flex flex-col md:flex-row items-center justify-between gap-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex-1 text-center md:text-left">
        <p className="font-bold text-lg text-gray-800">{match.team1.name}</p>
        <p className="text-sm text-gray-500">Capitán: {match.team1.captain}</p>
      </div>
      <div className="flex items-center gap-2">
        <Input
          type="number"
          value={match.score1}
          onChange={(e) => handleScoreChange(match.id, 1, e.target.value)}
          className="w-20 text-center"
          disabled={match.played}
        />
        <span className="font-bold text-xl text-gray-600">vs</span>
        <Input
          type="number"
          value={match.score2}
          onChange={(e) => handleScoreChange(match.id, 2, e.target.value)}
          className="w-20 text-center"
          disabled={match.played}
        />
      </div>
      <div className="flex-1 text-center md:text-right">
        <p className="font-bold text-lg text-gray-800">{match.team2.name}</p>
        <p className="text-sm text-gray-500">Capitán: {match.team2.captain}</p>
      </div>
      {!match.played && (
        <Button onClick={() => recordMatchResult(match.id)} primary={true} className="w-full md:w-auto">
          <Play className="w-4 h-4" /> Registrar
        </Button>
      )}
      {match.played && (
        <div className="text-green-600 font-semibold flex items-center gap-2">
          <Award className="w-5 h-5" />
          <span>Ganador: {match.winnerId === match.team1.id ? match.team1.name : match.team2.name}</span>
        </div>
      )}
    </motion.div>
  );

  return (
    <motion.div
      className="container mx-auto p-8 bg-white rounded-3xl shadow-xl my-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">Gestión del Torneo</h2>

      {teams.length === 0 ? (
        <motion.p
          className="text-center text-gray-500 py-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          Por favor, registra los equipos primero para iniciar el torneo.
        </motion.p>
      ) : (
        <>
          {currentRound === 0 && (
            <motion.div
              className="text-center mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <h3 className="text-2xl font-semibold text-gray-700 mb-4">¡Listo para la acción!</h3>
              <p className="text-gray-600 mb-6">Genera los partidos de la primera ronda para empezar.</p>
              <Button onClick={generateFirstRoundMatches}>
                <Shuffle className="w-5 h-5" /> Generar Primera Ronda
              </Button>
            </motion.div>
          )}

          {currentRound > 0 && (
            <>
              <h3 className="text-2xl font-semibold text-gray-700 mb-5 text-center">Ronda {currentRound}</h3>
              <div className="space-y-4 mb-8">
                <AnimatePresence>
                  {matches.map(renderMatch)}
                </AnimatePresence>
              </div>

              <div className="flex justify-center gap-4 mb-8">
                {allMatchesPlayed && currentRound < 5 && (
                  <Button onClick={generateNextRoundMatches}>
                    <Shuffle className="w-5 h-5" /> Generar Siguiente Ronda
                  </Button>
                )}
                {allMatchesPlayed && currentRound === 5 && (
                  <Button onClick={assignCategories}>
                    <ListOrdered className="w-5 h-5" /> Asignar Categorías (Día 1 Final)
                  </Button>
                )}
                <Button onClick={() => setShowRanking(!showRanking)} primary={false}>
                  <ListOrdered className="w-5 h-5" /> {showRanking ? 'Ocultar' : 'Mostrar'} Ranking
                </Button>
              </div>

              <AnimatePresence>
                {showRanking && (
                  <motion.div
                    className="bg-gray-50 p-6 rounded-2xl border border-gray-200 shadow-inner"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.4 }}
                  >
                    <h3 className="text-2xl font-semibold text-gray-700 mb-5 text-center">Ranking Actual</h3>
                    <div className="overflow-x-auto">
                      <table className="min-w-full bg-white rounded-lg shadow-sm">
                        <thead>
                          <tr className="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
                            <th className="py-3 px-6 text-left">Pos.</th>
                            <th className="py-3 px-6 text-left">Equipo</th>
                            <th className="py-3 px-6 text-center">Victorias</th>
                            <th className="py-3 px-6 text-center">Derrotas</th>
                            <th className="py-3 px-6 text-center">Puntos</th>
                            <th className="py-3 px-6 text-center">Coeficiente</th>
                            <th className="py-3 px-6 text-center">Categoría</th>
                          </tr>
                        </thead>
                        <tbody className="text-gray-700 text-sm font-light">
                          {getRankedTeams().map((team, index) => (
                            <motion.tr
                              key={team.id}
                              className="border-b border-gray-200 hover:bg-gray-50"
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.05 }}
                            >
                              <td className="py-3 px-6 text-left whitespace-nowrap font-medium">{index + 1}</td>
                              <td className="py-3 px-6 text-left">{team.name}</td>
                              <td className="py-3 px-6 text-center">{team.wins}</td>
                              <td className="py-3 px-6 text-center">{team.losses}</td>
                              <td className="py-3 px-6 text-center font-bold">{team.points}</td>
                              <td className="py-3 px-6 text-center">{team.coefficient.toFixed(2)}</td>
                              <td className="py-3 px-6 text-center">
                                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                  team.category === 'A' ? 'bg-blue-100 text-blue-800' :
                                  team.category === 'B' ? 'bg-green-100 text-green-800' :
                                  team.category === 'C' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                                }`}>
                                  {team.category || 'N/A'}
                                </span>
                              </td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {currentRound === 5 && allMatchesPlayed && (
                <motion.div
                  className="text-center mt-8 p-6 bg-blue-50 rounded-2xl border border-blue-200"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  <h3 className="text-2xl font-semibold text-blue-800 mb-4">¡Fin del Día 1!</h3>
                  <p className="text-blue-700 mb-6">Las 5 rondas suizas han concluido. Las categorías han sido asignadas.</p>
                  <Button onClick={handleDay2AdvanceMatch}>
                    <Play className="w-5 h-5" /> Iniciar Partidos de Avance (Día 2)
                  </Button>
                </motion.div>
              )}
            </>
          )}
        </>
      )}
    </motion.div>
  );
};

export default Tournament;
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PlusCircle, Save, XCircle } from 'lucide-react';
import Button from '../components/Button';
import Input from '../components/Input';
import TeamCard from '../components/TeamCard';

const Registration = ({ onRegisterTeams }) => {
  const [teams, setTeams] = useState([]);
  const [newTeam, setNewTeam] = useState({
    id: '',
    name: '',
    captain: '',
    players: ['', '', '', '']
  });
  const [isEditing, setIsEditing] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTeam(prev => ({ ...prev, [name]: value }));
  };

  const handlePlayerChange = (index, value) => {
    const updatedPlayers = [...newTeam.players];
    updatedPlayers[index] = value;
    setNewTeam(prev => ({ ...prev, players: updatedPlayers }));
  };

  const generateUniqueId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  const handleAddOrUpdateTeam = () => {
    if (!newTeam.name.trim() || !newTeam.captain.trim()) {
      alert('El nombre del equipo y el capitán son obligatorios.');
      return;
    }

    if (isEditing) {
      setTeams(prev => prev.map(team => team.id === newTeam.id ? newTeam : team));
      setIsEditing(false);
    } else {
      setTeams(prev => [...prev, { ...newTeam, id: generateUniqueId() }]);
    }
    setNewTeam({ id: '', name: '', captain: '', players: ['', '', '', ''] });
  };

  const handleEditTeam = (id) => {
    const teamToEdit = teams.find(team => team.id === id);
    setNewTeam(teamToEdit);
    setIsEditing(true);
  };

  const handleDeleteTeam = (id) => {
    setTeams(prev => prev.filter(team => team.id !== id));
  };

  const handleSaveAllTeams = () => {
    if (teams.length === 0) {
      alert('Por favor, registra al menos un equipo.');
      return;
    }
    onRegisterTeams(teams);
  };

  return (
    <motion.div
      className="container mx-auto p-8 bg-white rounded-3xl shadow-xl my-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">Registro de Equipos</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Formulario de Registro */}
        <motion.div
          className="bg-gray-50 p-6 rounded-2xl border border-gray-200 shadow-inner"
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h3 className="text-2xl font-semibold text-gray-700 mb-5">
            {isEditing ? 'Editar Equipo' : 'Registrar Nuevo Equipo'}
          </h3>
          <div className="space-y-4">
            <Input
              label="Nombre del Equipo"
              name="name"
              value={newTeam.name}
              onChange={handleInputChange}
              placeholder="Ej: Los Rodadores"
            />
            <Input
              label="Nombre del Capitán (Nombre y Apellido)"
              name="captain"
              value={newTeam.captain}
              onChange={handleInputChange}
              placeholder="Ej: Juan Pérez"
            />
            <p className="text-gray-600 font-medium mt-4 mb-2">Jugadores (hasta 4):</p>
            {newTeam.players.map((player, index) => (
              <Input
                key={index}
                value={player}
                onChange={(e) => handlePlayerChange(index, e.target.value)}
                placeholder={`Jugador ${index + 1}`}
              />
            ))}
            <Button onClick={handleAddOrUpdateTeam} className="w-full" primary={!isEditing}>
              {isEditing ? (
                <>
                  <Save className="w-5 h-5" /> Guardar Cambios
                </>
              ) : (
                <>
                  <PlusCircle className="w-5 h-5" /> Agregar Equipo
                </>
              )}
            </Button>
            {isEditing && (
              <Button onClick={() => {
                setIsEditing(false);
                setNewTeam({ id: '', name: '', captain: '', players: ['', '', '', ''] });
              }} className="w-full" primary={false}>
                <XCircle className="w-5 h-5" /> Cancelar Edición
              </Button>
            )}
          </div>
        </motion.div>

        {/* Lista de Equipos Registrados */}
        <motion.div
          className="bg-gray-50 p-6 rounded-2xl border border-gray-200 shadow-inner"
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <h3 className="text-2xl font-semibold text-gray-700 mb-5">Equipos Registrados ({teams.length})</h3>
          <div className="grid grid-cols-1 gap-4 max-h-96 overflow-y-auto pr-2">
            <AnimatePresence>
              {teams.length === 0 ? (
                <motion.p
                  className="text-center text-gray-500 py-10"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  Aún no hay equipos registrados. ¡Anímate a añadir el primero!
                </motion.p>
              ) : (
                teams.map(team => (
                  <TeamCard
                    key={team.id}
                    team={team}
                    onEdit={handleEditTeam}
                    onDelete={handleDeleteTeam}
                  />
                ))
              )}
            </AnimatePresence>
          </div>
          {teams.length > 0 && (
            <Button onClick={handleSaveAllTeams} className="w-full mt-6">
              <Save className="w-5 h-5" /> Iniciar Torneo
            </Button>
          )}
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Registration;